package com.hits.d2ddriver;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.Dash;
import com.google.android.gms.maps.model.Dot;
import com.google.android.gms.maps.model.Gap;
import com.google.android.gms.maps.model.JointType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PatternItem;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.RectangularBounds;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;
import org.jetbrains.annotations.NotNull;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;

public class Maps_Home extends FragmentActivity implements OnMapReadyCallback {

    SupportMapFragment mapFragment;
    FusedLocationProviderClient client;
    GoogleMap googleMap1;
    private Geocoder geocoder;
    Marker marker;
    private TransparentProgressDialog transparentProgressDialog;
    private String placename1,phone,vehcile,longitude,latitude,name,user_phone,user_uid,OTP;
    private TextView tvDistance, tvDuration,tvplacename;
    private LinearLayout directionDetailsLayout;
    LatLng curlatLng,latLng1,latLng_mid;
    AutocompleteSupportFragment autocompleteFragment;
    LocationRequest locationRequest;
    private static final int LOCATION_REQUEST_CODE = 100;
    private static Polyline polyline;
    Marker userLocationMarker;
    Circle userLocationAccuracyCircle;
    float Zoom=20;
    int t=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps__home);
        transparentProgressDialog = new TransparentProgressDialog(this, R.drawable.circle_loader, "");
        transparentProgressDialog.setCancelable(false);
        transparentProgressDialog.setCanceledOnTouchOutside(false);
        transparentProgressDialog.show();
        directionDetailsLayout = findViewById(R.id.Distance_direction);
        tvDistance = findViewById(R.id.Distance);
        tvDuration = findViewById(R.id.duration);
        tvplacename=findViewById(R.id.pl_name);
        mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.google_map);
        mapFragment.onCreate(savedInstanceState);
        mapFragment.getMapAsync(this);
        geocoder = new Geocoder(this);
        client = LocationServices.getFusedLocationProviderClient(this);
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(200);
        locationRequest.setFastestInterval(200);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ActivityCompat.checkSelfPermission(Maps_Home.this
                , Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
        } else {
            ActivityCompat.requestPermissions(Maps_Home.this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 44);
        }
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyDx5-n2oQNBf9z73zM8bB-t1Zr24mC-7xs");
        }
        autocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment);
        autocompleteFragment.setCountries("IN");
        autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));
        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NotNull Place place) {
                //Toast.makeText(MainActivity.this,place.getName()+""+place.getAddress(),Toast.LENGTH_LONG).show();
                try {
                    List<Address> addresses = geocoder.getFromLocation(place.getLatLng().latitude, place.getLatLng().longitude, 1);
                    if (addresses.size() > 0) {
                        Address address = addresses.get(0);
                        String streetAddress = address.getAddressLine(0);
                        MarkerOptions options = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.pin)).position(place.getLatLng()).title(place.getName()+","+streetAddress).draggable(true);
                        googleMap1.setOnMarkerDragListener(dragmarker);
                        //googleMap1.animateCamera(CameraUpdateFactory.newLatLngZoom(place.getLatLng(), 20));
                        if (marker != null){
                            marker.remove();
                        }
                        else {
                            Toast.makeText(Maps_Home.this,"Long Tap on Marker to Drag and Drop this Marker for more accurate results",Toast.LENGTH_LONG).show();
                        }
                        marker = googleMap1.addMarker(options);
                        marker.setDraggable(true);
                        latLng1=place.getLatLng();
                        googleMap1.setOnMarkerDragListener(dragmarker);
                        CameraPosition cameraPosition = new CameraPosition.Builder()
                                .target(place.getLatLng())
                                .zoom(19)
                                .tilt(0)
                                .build();
                        googleMap1.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                        placename1=place.getName();
                        polyline(curlatLng,latLng1);
                        latLng_mid=LatLngBounds.builder().include(latLng1).include(curlatLng).build().getCenter();
                        googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng_mid, Zoom));
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
            @Override
            public void onError(@NotNull Status status) {
            }
        });

    }



    public GoogleMap.OnMarkerDragListener dragmarker = new GoogleMap.OnMarkerDragListener() {
        @Override
        public void onMarkerDragStart(Marker marker) {
            Toast.makeText(Maps_Home.this,"Tap on Marker after Drag End to Update Location",Toast.LENGTH_LONG).show();
        }

        @Override
        public void onMarkerDrag(Marker marker) {

        }

        @Override
        public void onMarkerDragEnd(Marker marker) {
            LatLng latLng = marker.getPosition();
            try {
                List<Address> addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
                if (addresses.size() > 0) {
                    latLng1=latLng;
                    Address address = addresses.get(0);
                    String streetAddress = address.getAddressLine(0);
                    placename1=streetAddress;
                    marker.setTitle(streetAddress);
                    polyline(curlatLng,latLng1);
                    latLng_mid=LatLngBounds.builder().include(latLng1).include(curlatLng).build().getCenter();
                    googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng_mid, Zoom));
                    autocompleteFragment.setText(streetAddress);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    };


    @Override
    public void onMapReady(GoogleMap googleMap) {
        googleMap1 = googleMap;
        googleMap1.setBuildingsEnabled(true);
        //googleMap1.getUiSettings().setCompassEnabled(true);
        //googleMap1.setMyLocationEnabled(true);
        googleMap1.getUiSettings().setMapToolbarEnabled(false);
        googleMap1.getUiSettings().setMyLocationButtonEnabled(false);
        //enable_location();
    }
    public void polyline(LatLng latLng1,LatLng latLng2){
        List<PatternItem> pattern = Arrays.<PatternItem>asList(new Dot(), new Gap(20), new Dash(30), new Gap(20));
        PolylineOptions polylineOptions=new PolylineOptions();
        polylineOptions.clickable(false).geodesic(true).jointType(JointType.ROUND).pattern(pattern).color(Color.argb(90,255,0,0))
                .add(latLng1,latLng2);
        if(polyline!=null){
            polyline.remove();
        }
        else {
            latLng_mid=LatLngBounds.builder().include(latLng1).include(latLng2).build().getCenter();
            googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng_mid, Zoom));
        }
        polyline=googleMap1.addPolyline(polylineOptions);
        Direction_ditance();

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 44) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                checkSettingsAndStartLocationUpdates();
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            checkSettingsAndStartLocationUpdates();
        } else {
            askLocationPermission();
        }
    }

    @Override
    protected void onDestroy() {
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction("restartservice");
        broadcastIntent.setClass(this, Restarter.class);
        this.sendBroadcast(broadcastIntent);
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    private void checkSettingsAndStartLocationUpdates() {
        LocationSettingsRequest request = new LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest).build();
        SettingsClient client = LocationServices.getSettingsClient(this);

        Task<LocationSettingsResponse> locationSettingsResponseTask = client.checkLocationSettings(request);
        locationSettingsResponseTask.addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                startLocationUpdates();
            }
        });
        locationSettingsResponseTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if (e instanceof ResolvableApiException) {
                    ResolvableApiException apiException = (ResolvableApiException) e;
                    try {
                        apiException.startResolutionForResult(Maps_Home.this, 1001);
                    } catch (IntentSender.SendIntentException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
    }

    private void askLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            }
        }
    }

    LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            super.onLocationResult(locationResult);
            if (googleMap1 != null) {
                setUserLocationMarker(locationResult.getLastLocation());
            }
        }
    };
    private LatLngBounds setBounds(Location location, int mDistanceInMeters ){
        double latRadian = Math.toRadians(location.getLatitude());

        double degLatKm = 110.574235;
        double degLongKm = 110.572833 * Math.cos(latRadian);
        double deltaLat = mDistanceInMeters / 1000.0 / degLatKm;
        double deltaLong = mDistanceInMeters / 1000.0 / degLongKm;

        double minLat = location.getLatitude() - deltaLat;
        double minLong = location.getLongitude() - deltaLong;
        double maxLat = location.getLatitude() + deltaLat;
        double maxLong = location.getLongitude() + deltaLong;
        return new LatLngBounds(new LatLng(minLat, minLong), new LatLng(maxLat, maxLong));
    }

    private void setUserLocationMarker(Location location) {
        autocompleteFragment.setLocationBias(RectangularBounds.newInstance(setBounds(location,5000)));
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        curlatLng=latLng;

        if (userLocationMarker == null) {
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(latLng);
            markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.cursor));
            markerOptions.rotation(location.getBearing());
            markerOptions.anchor((float) 0.5, (float) 0.5);
            userLocationMarker = googleMap1.addMarker(markerOptions);
            googleMap1.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 19));

        } else {
            userLocationMarker.setPosition(latLng);
            userLocationMarker.setRotation(location.getBearing());
            if (polyline!=null){
                polyline(curlatLng,latLng1);
            }
        }
        if (userLocationAccuracyCircle == null) {
            CircleOptions circleOptions = new CircleOptions();
            circleOptions.center(latLng);
            circleOptions.strokeWidth((float) 0.5);
            circleOptions.strokeColor(Color.argb(100, 0, 30, 255));
            circleOptions.fillColor(Color.argb(32, 0, 30, 255));
            circleOptions.radius(location.getAccuracy());
            userLocationAccuracyCircle = googleMap1.addCircle(circleOptions);
        } else {
            userLocationAccuracyCircle.setCenter(latLng);
            userLocationAccuracyCircle.setRadius(location.getAccuracy());
        }
        transparentProgressDialog.dismiss();
        if(t==0){
            startService(new Intent(this,MyService.class));
            t=1;
        }
    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        client.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
    }

    private void stopLocationUpdates() {
        client.removeLocationUpdates(locationCallback);
    }

    public void Direction(View view) {
        Intent intent = new Intent(Maps_Home.this,Maps_Direction.class);
        Bundle b = new Bundle();
        b.putDouble("lat2", latLng1.latitude);
        b.putDouble("long2", latLng1.longitude);
        b.putDouble("lat1",curlatLng.latitude);
        b.putDouble("long1",curlatLng.longitude);
        b.putString("placename",placename1);
        intent.putExtras(b);
        startActivity(intent);
    }

    public void current(View view) {
        googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(curlatLng, 19));
    }

    public void location_off(View view) {
        if(polyline!=null){
            polyline.remove();
            marker.remove();
            polyline=null;
            placename1=null;
            directionDetailsLayout.setVisibility(View.INVISIBLE);
            googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(curlatLng,19));
        }
    }
    public void Direction_ditance() {
        directionDetailsLayout.setVisibility(View.VISIBLE);
        float[] results=new float[10];
        Location.distanceBetween(curlatLng.latitude,curlatLng.longitude,latLng1.latitude,latLng1.longitude,results);
        tvDistance.setText(getFormattedDistance(results[0]));
        tvDuration.setText(getFormattedDuration(results[0]*0.25));
        tvplacename.setText(placename1);

    }
    private String getFormattedDistance(double distance) {
        if((distance<=500))
            Zoom= (float) 18;
        if((distance<=1000)&&(distance>500))
            Zoom= (float) 16.5;
        if((distance<=1500)&&(distance>1000))
            Zoom= (float) 16;
        if((distance<=2000)&&(distance>1500))
            Zoom= (float) 15.7;
        if((distance<=2500)&&(distance>2000))
            Zoom= (float) 15.2;
        if((distance<=3000)&&(distance>2500))
            Zoom= (float) 14.5;
        if((distance<=3500)&&(distance>3000))
            Zoom= (float) 14;
        if((distance<=4000)&&(distance>3000))
            Zoom= (float) 14.5;
        if((distance<=5000)&&(distance>4000))
            Zoom= (float) 14;
        if((distance<=6000)&&(distance>5000))
            Zoom= (float) 13;
        if((distance<=7000)&&(distance>6000))
            Zoom= (float) 12.2;
        if((distance<=8500)&&(distance>7000))
            Zoom= (float) 11.6;
        if((distance<=10000)&&(distance>8500))
            Zoom= (float) 11;
        if((distance<=20000)&&(distance>10000))
            Zoom= (float) 10;
        if((distance<=35000)&&(distance>20000))
            Zoom= (float) 9.5;
        if((distance<=50000)&&(distance>35000))
            Zoom= (float) 9;
        if((distance<=100000)&&(distance>50000))
            Zoom= (float) 8;
        if((distance>100000))
            Zoom= (float) 6;
        if ((distance / 1000) < 1) {
            DecimalFormat decimalFormat = new DecimalFormat("#.#");
            return decimalFormat.format(distance) + "mtr.";
        }
        DecimalFormat decimalFormat = new DecimalFormat("#.#");
        return decimalFormat.format(distance / 1000) + "Km.";
    }

    private String getFormattedDuration(double duration) {
        long min = (long) (duration % 3600 / 60);
        long hours = (long) (duration % 86400 / 3600);
        long days = (long) (duration / 86400);
        if (days > 0L) {
            return days + " " + (days > 1L ? "Days" : "Day") + " " + hours + " " + "hr" + (min > 0L ? " " + min + " " + "min." : "");
        } else {
            return hours > 0L ? hours + " " + "hr" + (min > 0L ? " " + min + " " + "min" : "") : min + " " + "min.";
        }
    }

}
