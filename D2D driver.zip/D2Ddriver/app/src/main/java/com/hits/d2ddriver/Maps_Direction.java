package com.hits.d2ddriver;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class Maps_Direction extends AppCompatActivity implements OnMapReadyCallback {
    private double lat1,long1,lat2,long2;
    private String placename;
    GoogleMap googleMap1;
    LatLng latLng1,latLng2,latLng_mid;
    float Zoom=0;
    private static final int LOCATION_REQUEST_CODE = 100;
    Polyline polyline;
    Marker userLocationMarker;
    Circle userLocationAccuracyCircle;
    SupportMapFragment mapFragment;
    FusedLocationProviderClient client;
    LocationRequest locationRequest;
    private TabLayout profileTabLayout;
    String mode;
    Location location1;
    int t=0;
    private AppCompatButton Nav,Dir;
    private TransparentProgressDialog transparentProgressDialog;
    private String placename1,phone,vehcile,longitude,latitude,name,user_phone,user_uid,OTP;
    private TextView tvDistance, tvDuration,tvplacename;
    private LinearLayout directionDetailsLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps__direction);
        Bundle b = getIntent().getExtras();
        lat2 = b.getDouble("lat2");
        long2 = b.getDouble("long2");
        lat1 = b.getDouble("lat1");
        long1 = b.getDouble("long1");
        placename=b.getString("placename");
        transparentProgressDialog = new TransparentProgressDialog(this, R.drawable.circle_loader, "");
        transparentProgressDialog.setCancelable(false);
        transparentProgressDialog.setCanceledOnTouchOutside(false);
        transparentProgressDialog.show();
        directionDetailsLayout = findViewById(R.id.Distance_direction);
        tvDistance = findViewById(R.id.Distance);
        tvDuration = findViewById(R.id.duration);
        tvplacename=findViewById(R.id.pl_name);
        tvplacename.setText(placename);
        latLng1=new LatLng(lat1,long1);
        latLng2=new LatLng(lat2,long2);
        Dir = findViewById(R.id.dir);
        Dir.setEnabled(false);
        Nav=findViewById(R.id.nav);
        profileTabLayout = findViewById(R.id.tab_layout_profile);
        mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.google_map);
        mapFragment.onCreate(savedInstanceState);
        mapFragment.getMapAsync(this);
        client = LocationServices.getFusedLocationProviderClient(this);
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(100);
        locationRequest.setFastestInterval(100);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        profileTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (googleMap1 == null) {
                    if (profileTabLayout.getTabAt(0) != null) {
                        Objects.requireNonNull(profileTabLayout.getTabAt(0)).select();
                        return;
                    }
                }
                switch (tab.getPosition()) {
                    case 0:
                        mode="driving";
                        break;

                    case 1:
                        mode="bycycling";
                        break;

                    case 2:
                        mode="walking";
                        break;

                    default:
                        mode="driving";
                        break;
                }
                transparentProgressDialog.show();
                startLocationUpdates();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });



    }

    private String getDirectionsUrl(LatLng origin,LatLng dest){
        String str_origin = "origin="+origin.latitude+","+origin.longitude;
        String str_dest = "destination="+dest.latitude+","+dest.longitude;
        String sensor = "sensor=true";
        String parameters = str_origin+"&"+str_dest+"&"+sensor;
        String output = "json";
        String url = "https://maps.googleapis.com/maps/api/directions/"+output+"?"+parameters+"&mode="+mode+"&dir_action=navigate&optimize:true&key=AIzaSyDx5-n2oQNBf9z73zM8bB-t1Zr24mC-7xs";
        return url;
    }
    @Override
    protected void onStart() {
        super.onStart();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            checkSettingsAndStartLocationUpdates();
        } else {
            askLocationPermission();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopLocationUpdates();
    }
    private void checkSettingsAndStartLocationUpdates() {
        LocationSettingsRequest request = new LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest).build();
        SettingsClient client = LocationServices.getSettingsClient(this);

        Task<LocationSettingsResponse> locationSettingsResponseTask = client.checkLocationSettings(request);
        locationSettingsResponseTask.addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                startLocationUpdates();
            }
        });
        locationSettingsResponseTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if (e instanceof ResolvableApiException) {
                    ResolvableApiException apiException = (ResolvableApiException) e;
                    try {
                        apiException.startResolutionForResult(Maps_Direction.this, 1001);
                    } catch (IntentSender.SendIntentException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
    }

    private void askLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            }
        }
    }

    LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            super.onLocationResult(locationResult);
            if (googleMap1 != null) {
                setUserLocationMarker(locationResult.getLastLocation());
            }
        }
    };
    private void getDirections(LatLng latLng1, LatLng latLng2) {
        //googleMap1.clear();
        MarkerOptions options = new MarkerOptions().position(latLng2).title(placename);
        //googleMap1.addMarker(options);
        if(t==0)direction_enabled();
        t=1;
        String url = getDirectionsUrl(latLng1, latLng2);
        DownloadTask downloadTask = new DownloadTask();
        downloadTask.map(googleMap1,tvDuration,tvDistance,location1,options);
        downloadTask.execute(url);
        directionDetailsLayout.setVisibility(View.VISIBLE);
    }
    private void setUserLocationMarker(Location location) {
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        latLng1=latLng;
        location1=location;
        //userLocationMarker=null;
        //userLocationAccuracyCircle=null;
        getDirections(latLng1,latLng2);
        transparentProgressDialog.dismiss();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 44) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                checkSettingsAndStartLocationUpdates();
                //getCurrentLocation();
                //enable_location();
            }
        }
    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        client.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
    }

    private void stopLocationUpdates() {
        client.removeLocationUpdates(locationCallback);
    }

    public void navigate(View view) {
        Nav.setVisibility(View.INVISIBLE);
        Dir.setVisibility(View.VISIBLE);
        Nav.setEnabled(false);

        Dir.setEnabled(true);
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(latLng1)
                .zoom(20)
                .tilt(60)
                .bearing(location1.getBearing())
                .build();
        googleMap1.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
    }

    public void direction(View view) {
        direction_enabled();
    }

    private void direction_enabled() {
        Dir.setVisibility(View.INVISIBLE);
        Nav.setVisibility(View.VISIBLE);
        Dir.setEnabled(false);
        Nav.setEnabled(true);
        float[] results=new float[10];
        Location.distanceBetween(latLng2.latitude,latLng2.longitude,latLng1.latitude,latLng1.longitude,results);
        Zoom=getFormattedDistance(results[0]);
        latLng_mid= LatLngBounds.builder().include(latLng1).include(latLng2).build().getCenter();
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(latLng_mid)
                .zoom(Zoom)
                .bearing(location1.getBearing())
                .build();
        googleMap1.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
    }

    private float getFormattedDistance(double distance) {
        if ((distance <= 500))
            Zoom = (float) 18;
        if ((distance <= 1000) && (distance > 500))
            Zoom = (float) 16.5;
        if ((distance <= 1500) && (distance > 1000))
            Zoom = (float) 16;
        if ((distance <= 2000) && (distance > 1500))
            Zoom = (float) 15.7;
        if ((distance <= 2500) && (distance > 2000))
            Zoom = (float) 15.2;
        if ((distance <= 3000) && (distance > 2500))
            Zoom = (float) 14.5;
        if ((distance <= 3500) && (distance > 3000))
            Zoom = (float) 14;
        if ((distance <= 4000) && (distance > 3000))
            Zoom = (float) 14.5;
        if ((distance <= 5000) && (distance > 4000))
            Zoom = (float) 14;
        if ((distance <= 6000) && (distance > 5000))
            Zoom = (float) 13;
        if ((distance <= 7000) && (distance > 6000))
            Zoom = (float) 12.2;
        if ((distance <= 8500) && (distance > 7000))
            Zoom = (float) 11.6;
        if ((distance <= 10000) && (distance > 8500))
            Zoom = (float) 11;
        if ((distance <= 20000) && (distance > 10000))
            Zoom = (float) 10;
        if ((distance <= 35000) && (distance > 20000))
            Zoom = (float) 9.5;
        if ((distance <= 50000) && (distance > 35000))
            Zoom = (float) 9;
        if ((distance <= 100000) && (distance > 50000))
            Zoom = (float) 8;
        if ((distance > 100000))
            Zoom = (float) 6;
        return Zoom;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        googleMap1 = googleMap;
        googleMap1.setBuildingsEnabled(true);
        googleMap1.getUiSettings().setMapToolbarEnabled(false);
        googleMap1.getUiSettings().setMyLocationButtonEnabled(false);

    }

    public void Recenter(View view) {
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(latLng1)
                .zoom(20)
                .tilt(60)
                .bearing(location1.getBearing())
                .build();
        googleMap1.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
    }
}

class DownloadTask extends AsyncTask<String, Void, String> {
    GoogleMap googleMap;
    TextView distance,duration;
    Polyline polyline1;
    Location location1;
    MarkerOptions options;
    @Override
    protected String doInBackground(String... url) {
        String data = "";
        try{
            data = downloadUrl(url[0]);
        }catch(Exception e){
        }
        return data;
    }
    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        ParserTask parserTask = new ParserTask();
        parserTask.map(googleMap,distance,duration,location1,options);
        parserTask.execute(result);
        polyline1=parserTask.polyline;

    }
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try{
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();
            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));
            StringBuffer sb = new StringBuffer();
            String line = "";
            while( ( line = br.readLine()) != null){
                sb.append(line);
            }
            data = sb.toString();
            br.close();
        }catch(Exception e){
        }finally{
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    public void map(GoogleMap googleMap1,TextView Duration,TextView Distance,Location location,MarkerOptions markerOptions) {
        googleMap=googleMap1;
        distance=Distance;
        duration=Duration;
        location1=location;
        options=markerOptions;
    }
}
class ParserTask extends AsyncTask<String, Integer, List<List<HashMap<String,String>>> >{
    GoogleMap map;
    TextView Distance,Duration;
    Polyline polyline;
    Location location1;
    Marker userLocationMarker;
    Circle userLocationAccuracyCircle;
    PolylineOptions lineOptions;
    MarkerOptions mark;

    @Override
    protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

        JSONObject jObject;
        List<List<HashMap<String, String>>> routes = null;

        try{
            jObject = new JSONObject(jsonData[0]);
            DirectionsJSONParser parser = new DirectionsJSONParser();
            routes = parser.parse(jObject);
        }catch(Exception e){
            e.printStackTrace();
        }
        return routes;
    }
    @Override
    protected void onPostExecute(List<List<HashMap<String, String>>> result) {
        ArrayList points = null;
        String distance = "";
        String duration = "";

        if(result.size()<1){
            return;
        }
        for(int i=0;i<result.size();i++){
            points = new ArrayList();
            lineOptions = new PolylineOptions();
            List<HashMap<String, String>> path = result.get(i);

            for(int j=0;j <path.size();j++){
                HashMap<String,String> point = path.get(j);

                if(j==0){
                    distance = (String)point.get("distance");
                    continue;
                }else if(j==1){
                    duration = (String)point.get("duration");
                    continue;
                }

                double lat = Double.parseDouble(point.get("lat"));
                double lng = Double.parseDouble(point.get("lng"));
                LatLng position = new LatLng(lat, lng);

                points.add(position);
            }
            lineOptions.addAll(points);
            lineOptions.width(12);
            lineOptions.color(Color.RED);
        }
        map.clear();
        if (userLocationMarker == null) {
            MarkerOptions markerOptions1 = new MarkerOptions();
            markerOptions1.position(new LatLng(location1.getLatitude(),location1.getLongitude()));
            markerOptions1.icon(BitmapDescriptorFactory.fromResource(R.drawable.cursor));
            markerOptions1.rotation(location1.getBearing());
            markerOptions1.anchor((float) 0.5, (float) 0.5);
            userLocationMarker = map.addMarker(markerOptions1);
        } else {
            userLocationMarker.setPosition(new LatLng(location1.getLatitude(),location1.getLongitude()));
            userLocationMarker.setRotation(location1.getBearing());
        }
        if (userLocationAccuracyCircle == null) {
            CircleOptions circleOptions = new CircleOptions();
            circleOptions.center(new LatLng(location1.getLatitude(),location1.getLongitude()));
            circleOptions.strokeWidth((float) 0.5);
            circleOptions.strokeColor(Color.argb(100, 0, 30, 255));
            circleOptions.fillColor(Color.argb(32, 0, 30, 255));
            circleOptions.radius(location1.getAccuracy());
            userLocationAccuracyCircle = map.addCircle(circleOptions);
        } else {
            userLocationAccuracyCircle.setCenter(new LatLng(location1.getLatitude(),location1.getLongitude()));
            userLocationAccuracyCircle.setRadius(location1.getAccuracy());
        }
        map.addMarker(mark);
        Distance.setText(distance);
        Duration.setText(duration);
        polyline=map.addPolyline(lineOptions);
    }
    public void map(GoogleMap googleMap,TextView distance,TextView duration,Location location,MarkerOptions options) {
        map=googleMap;
        Distance=distance;
        Duration=duration;
        location1=location;
        mark=options;
    }
}
