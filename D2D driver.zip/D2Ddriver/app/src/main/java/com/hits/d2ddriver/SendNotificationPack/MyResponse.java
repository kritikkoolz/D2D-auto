package com.hits.d2ddriver.SendNotificationPack;

public class MyResponse {
    public int success;

}
