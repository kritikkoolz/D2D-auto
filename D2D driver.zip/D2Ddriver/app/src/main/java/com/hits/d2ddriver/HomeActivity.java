package com.hits.d2ddriver;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.mapbox.android.core.location.LocationEngine;
import com.mapbox.android.core.location.LocationEngineListener;
import com.mapbox.geojson.Point;
import com.mapbox.mapboxsdk.annotations.MarkerOptions;
import com.mapbox.mapboxsdk.camera.CameraPosition;
import com.mapbox.mapboxsdk.camera.CameraUpdateFactory;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.location.LocationComponent;
import com.mapbox.mapboxsdk.location.LocationComponentOptions;
import com.mapbox.mapboxsdk.location.modes.CameraMode;
import com.mapbox.mapboxsdk.location.modes.RenderMode;
import com.mapbox.mapboxsdk.maps.MapView;
import com.mapbox.mapboxsdk.maps.MapboxMap;
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback;
import com.mapbox.mapboxsdk.style.sources.GeoJsonOptions;
import com.mapmyindia.sdk.plugin.annotation.LineManager;
import com.mapmyindia.sdk.plugin.annotation.LineOptions;
import com.mmi.services.api.autosuggest.model.AutoSuggestAtlasResponse;
import com.mmi.services.api.autosuggest.model.ELocation;
import com.mmi.services.api.directions.DirectionsCriteria;
import com.mmi.services.api.distance.MapmyIndiaDistanceMatrix;
import com.mmi.services.api.distance.models.DistanceResponse;
import com.mmi.services.api.distance.models.DistanceResults;
import com.mmi.services.api.textsearch.MapmyIndiaTextSearch;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity implements OnMapReadyCallback, LocationEngineListener, TextWatcher, TextView.OnEditorActionListener {
    private static final int MY_PERMISSIONS_REQUEST_FINE_LOCATION = 100;
    private LocationComponent locationComponent;
    private MapboxMap mapmyIndiaMaps;
    private LocationEngine locationEngine;
    private MapView mapView;
    private ImageView iv1;
    private List<LatLng> listOfLatLng;
    private EditText autoSuggestText;
    private RecyclerView recyclerView;
    private LineManager lineManager;
    private LinearLayoutManager mLayoutManager;
    private TransparentProgressDialog transparentProgressDialog;
    private Handler handler;
    private int tp=0;
    private String placename1,phone,vehcile,longitude,latitude,name,user_phone,user_uid,OTP;
    private TextView tvDistance, tvDuration,tvplacename;
    private LinearLayout directionDetailsLayout;
    private double lat1,long1, lat2=0 ,long2=0,long3=0,lat3=0;
    private int vt,tb=0;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mapView = findViewById(R.id.map_view);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);
        initReferences();
        initListeners();
        autoSuggestText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                tp=0;
                return false;
            }
        });
        notification();
    }

    private void initListeners() {
       autoSuggestText.addTextChangedListener(this);
        autoSuggestText.setOnEditorActionListener(this);
    }
    public void notification(){
        DatabaseReference mDatabase;
        mDatabase = FirebaseDatabase.getInstance().getReference().child("D2D driver").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Information");
        String refreshToken= FirebaseInstanceId.getInstance().getToken();
        mDatabase.child("Token").setValue(refreshToken);
        mDatabase.child("Success").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.getValue().toString().equals("true")){
                    mDatabase.child("user id").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            user_uid=snapshot.getValue().toString();
                            FirebaseDatabase.getInstance().getReference().child("Tokens").child("User").child(user_uid).child("Alloted").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if(snapshot.getValue().toString().equals("true")){
                                        Toast.makeText(com.hits.d2ddriver.HomeActivity.this,"Ride Already In progress You are late!",Toast.LENGTH_LONG).show();
                                    }
                                    else {
                                        FirebaseDatabase.getInstance().getReference().child("Tokens").child("User").child(user_uid).child("Accepted").addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                if(snapshot.getValue().toString().equals("true")){
                                                    Toast.makeText(com.hits.d2ddriver.HomeActivity.this,"Ride Already Accepted by other You are late!",Toast.LENGTH_LONG).show();
                                                }
                                                else{
                                                    showCustomDialog_tick();
                                                }

                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });
                                    }

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

    }
    private void initReferences() {
        iv1=(ImageView)findViewById(R.id.iv);
        iv1.setVisibility(View.INVISIBLE);
        autoSuggestText = findViewById(R.id.auto_suggest);
        recyclerView = findViewById(R.id.recyclerview);
        mLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setVisibility(View.GONE);
        directionDetailsLayout = findViewById(R.id.Distance_direction);
        tvDistance = findViewById(R.id.Distance);
        tvDuration = findViewById(R.id.duration);
        tvplacename=findViewById(R.id.pl_name);
        transparentProgressDialog = new TransparentProgressDialog(this, R.drawable.circle_loader, "");
        transparentProgressDialog.setCancelable(false);
        transparentProgressDialog.setCanceledOnTouchOutside(false);
        handler = new Handler();
    }

    @Override
    public void onMapReady(MapboxMap mapmyIndiaMaps) {
        this.mapmyIndiaMaps = mapmyIndiaMaps;
        lineManager = new LineManager(mapView, mapmyIndiaMaps, null, new GeoJsonOptions().withLineMetrics(true).withBuffer(2));
        enableLocation();
    }

    @Override
    public void onMapError(int i, String s) {

    }

    private void enableLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_FINE_LOCATION);
            return;
        }
        LocationComponentOptions options = LocationComponentOptions.builder(this)
                .trackingGesturesManagement(true)
                .accuracyColor(ContextCompat.getColor(this, R.color.teal_200))
                .foregroundDrawable(R.drawable.location_pointer)
                .build();
        locationComponent = mapmyIndiaMaps.getLocationComponent();
        locationComponent.activateLocationComponent(this, options);
        locationComponent.setLocationComponentEnabled(true);
        locationEngine = locationComponent.getLocationEngine();
        locationEngine.addLocationEngineListener(this);
        locationComponent.setCameraMode(CameraMode.TRACKING);
        locationComponent.setRenderMode(RenderMode.COMPASS);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_FINE_LOCATION: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    enableLocation();

                } else {
                    iv1.setVisibility(View.VISIBLE);
                    mapView.setVisibility(View.INVISIBLE);

                }
                return;
            }
        }
    }

    @Override
    protected void onStart() {
        mapView.onStart();
        super.onStart();


    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
        if (locationEngine != null) {
            locationEngine.removeLocationEngineListener(this);
            locationEngine.addLocationEngineListener(this);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
        if (locationEngine != null)
            locationEngine.removeLocationEngineListener(this);
    }


    @Override
    protected void onStop() {
        super.onStop();
        mapView.onStop();
        if (locationEngine != null) {
            locationEngine.removeLocationEngineListener(this);
            locationEngine.removeLocationUpdates();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
        if (locationEngine != null) {
            locationEngine.deactivate();
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    public void onConnected() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this, // Activity
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_FINE_LOCATION);
            return;
        }
        locationEngine.requestLocationUpdates();

    }
    private String getFormattedDistance(double distance) {

        if ((distance / 1000) < 1) {
            return distance + "mtr.";
        }
        DecimalFormat decimalFormat = new DecimalFormat("#.#");
        return decimalFormat.format(distance / 1000) + "Km.";
    }

    private String getFormattedDuration(double duration) {
        long min = (long) (duration % 3600 / 60);
        long hours = (long) (duration % 86400 / 3600);
        long days = (long) (duration / 86400);
        if (days > 0L) {
            return days + " " + (days > 1L ? "Days" : "Day") + " " + hours + " " + "hr" + (min > 0L ? " " + min + " " + "min." : "");
        } else {
            return hours > 0L ? hours + " " + "hr" + (min > 0L ? " " + min + " " + "min" : "") : min + " " + "min.";
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        if(tb!=1)
        mapmyIndiaMaps.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), 16));
        lat1=location.getLatitude();
        long1=location.getLongitude();
        FirebaseDatabase.getInstance().getReference().child("D2D driver").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Information").child("latitude").setValue(lat1);
        FirebaseDatabase.getInstance().getReference().child("D2D driver").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Information").child("longitude").setValue(long1);
        vt=1;
        if(lat2!=0)
        polyline();

    }
    public void selectedPlace(ELocation eLocation) {
        String add = "Latitude: " + eLocation.latitude + " longitude: " + eLocation.longitude;
        tp=1;
        autoSuggestText.setText(eLocation.placeName);
        autoSuggestText.clearFocus();
        InputMethodManager in = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        in.hideSoftInputFromWindow(autoSuggestText.getWindowToken(), 0);
        addMarker(Double.parseDouble(eLocation.latitude), Double.parseDouble(eLocation.longitude) , eLocation.placeName);
        showToast(add);
    }



    private void addMarker(double latitude, double longitude , String placename) {
        mapmyIndiaMaps.clear();
        if(lineManager != null) {
            lineManager.clearAll();
        }
        lat2=latitude;
        long2=longitude;
        placename1=placename;
        mapmyIndiaMaps.addMarker(new MarkerOptions().position(new LatLng(
                latitude, longitude)).title(placename));
        CameraPosition cameraPosition = new CameraPosition.Builder().target(new LatLng(
                latitude, longitude)).zoom(8).tilt(0).build();
        mapmyIndiaMaps.setCameraPosition(cameraPosition);
        polyline();

    }
    private void polyline(){
        if(lineManager != null) {
            lineManager.clearAll();
            listOfLatLng = SemiCirclePointsListHelper.showCurvedPolyline(new LatLng(lat2, long2), new LatLng(lat1, long1), 50);
            LineOptions lineOptions = new LineOptions()
                    .points(listOfLatLng)
                    .lineColor("#FF0000")
                    .lineWidth(4f);
            lineManager.setLineDasharray(new Float[]{95f, 05f});
            lineManager.create(lineOptions);
            List<Point> coordinatesPoint = new ArrayList<Point>();
            coordinatesPoint.add(Point.fromLngLat(long2, lat2));
            coordinatesPoint.add(Point.fromLngLat(long1, lat1));
            if (CheckInternet.isNetworkAvailable(this)) {
                calculateDistance(coordinatesPoint);
                vt=0;
            } else {
                Toast.makeText(this, getString(R.string.pleaseCheckInternetConnection), Toast.LENGTH_SHORT).show();
            }
        }

    }

    private void calculateDistance(List<Point> pointList) {
        if(vt!=1) {
            show();
        }
        MapmyIndiaDistanceMatrix.builder()
                .coordinates(pointList)
                .profile(DirectionsCriteria.PROFILE_DRIVING)
                .resource(DirectionsCriteria.RESOURCE_DISTANCE_ETA)
                .build()
                .enqueueCall(new Callback<DistanceResponse>() {
                    @Override
                    public void onResponse(Call<DistanceResponse> call, Response<DistanceResponse> response) {
                        hide();
                        if (response.code() == 200) {
                            if (response.body() != null) {
                                DistanceResponse legacyDistanceResponse = response.body();
                                DistanceResults distanceResults = legacyDistanceResponse.results();

                                if (distanceResults != null) {
                                    updateData(distanceResults);
                                } else {
                                    Toast.makeText(com.hits.d2ddriver.HomeActivity.this, "Failed: " + legacyDistanceResponse.responseCode(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<DistanceResponse> call, Throwable t) {
                        hide();
                    }
                });
    }


    private void updateData(DistanceResults distanceResults) {

        directionDetailsLayout.setVisibility(View.VISIBLE);
        tb=1;
        tvDuration.setText(getFormattedDuration(distanceResults.durations().get(0)[1]));
        tvDistance.setText(getFormattedDistance(distanceResults.distances().get(0)[1]));
        tvplacename.setText(placename1);
    }
    private void callTextSearchApi(String searchString){
        MapmyIndiaTextSearch.builder()
                .query(searchString)
                .build().enqueueCall(new Callback<AutoSuggestAtlasResponse>() {
            @Override
            public void onResponse(Call<AutoSuggestAtlasResponse> call, Response<AutoSuggestAtlasResponse> response) {
                if (response.code() == 200) {
                    if (response.body() != null) {
                        ArrayList<ELocation> suggestedList = response.body().getSuggestedLocations();
                        if (suggestedList.size() > 0) {
                            recyclerView.setVisibility(View.VISIBLE);
                            AutoSuggestAdapter autoSuggestAdapter = new AutoSuggestAdapter(suggestedList, eLocation -> {
                                selectedPlace(eLocation);
                                recyclerView.setVisibility(View.GONE);
                            });
                            recyclerView.setAdapter(autoSuggestAdapter);
                        }
                    } else {
                        showToast("Not able to get value, Try again.");
                    }
                }
            }
            @Override
            public void onFailure(Call<AutoSuggestAtlasResponse> call, Throwable t) {
                showToast(t.toString());
            }
        });
    }

    private void show() {
        transparentProgressDialog.show();
    }

    private void hide() {
        transparentProgressDialog.dismiss();
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        handler.postDelayed(() -> {
            recyclerView.setVisibility(View.GONE);
            if (s.length() < 3)
                recyclerView.setAdapter(null);

            if (s != null && s.toString().trim().length() < 2) {
                recyclerView.setAdapter(null);
                return;
            }
            if (s.length() > 3 && tp==1)
                recyclerView.setAdapter(null);

            if (s.length() > 2 && tp==0) {
                if (CheckInternet.isNetworkAvailable(this)) {
                    callTextSearchApi(s.toString());
                } else {
                    showToast(getString(R.string.pleaseCheckInternetConnection));
                }
            }
        }, 3);

    }

    @Override
    public void afterTextChanged(Editable s) {
    }


    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId== EditorInfo.IME_ACTION_SEARCH){
            callTextSearchApi(v.getText().toString());
            autoSuggestText.clearFocus();
            InputMethodManager in = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            in.hideSoftInputFromWindow(autoSuggestText.getWindowToken(), 0);
            return true;
        }
        return false;
    }

    public void hide1(View view) {
        recyclerView.setVisibility(View.INVISIBLE);
    }

    public void location_off(View view) {
        mapmyIndiaMaps.clear();
        if(lineManager != null) {
            lineManager.clearAll();
            tb=0;
            directionDetailsLayout.setVisibility(View.GONE);
        }
    }

    public void current(View view) {
        CameraPosition cameraPosition = new CameraPosition.Builder().target(new LatLng(
                lat1, long1)).zoom(16).tilt(0).build();
        mapmyIndiaMaps.setCameraPosition(cameraPosition);
    }

    public void Direction(View view) {
        Intent intent = new Intent(com.hits.d2ddriver.HomeActivity.this, com.hits.d2ddriver.Direction.class);
        Bundle b = new Bundle();
        b.putDouble("lat2", lat2);
        b.putDouble("long2", long2);
        b.putDouble("lat1",lat1);
        b.putDouble("long1",long1);
        b.putString("placename",placename1);
        intent.putExtras(b);
        startActivity(intent);
    }
    private void showCustomDialog_tick() {
        FirebaseDatabase.getInstance().getReference().child("Tokens").child("Driver").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Success").setValue("false");
        DatabaseReference dbef = FirebaseDatabase.getInstance().getReference().child("D2D driver").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Information");
        dbef.child("Vehcile_No").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                vehcile=snapshot.getValue().toString();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        name=FirebaseAuth.getInstance().getCurrentUser().getDisplayName();
        phone=FirebaseAuth.getInstance().getCurrentUser().getPhoneNumber();
        ViewGroup viewGroup = findViewById(android.R.id.content);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.ride_response, viewGroup, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
        alertDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.setCancelable(false);
        Handler handler1 = new Handler();
        handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                alertDialog.dismiss();
            }
        },90000);
        Button bt = (Button) dialogView.findViewById(R.id.buttonaccept);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbef.child("Live").setValue("false");
                dbef.child("user id").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        user_uid=snapshot.getValue().toString();
                        FirebaseDatabase.getInstance().getReference().child("Tokens").child("User").child(snapshot.getValue().toString()).child("Alloted").setValue("true");
                        FirebaseDatabase.getInstance().getReference().child("Tokens").child("User").child(snapshot.getValue().toString()).child("Accepted").setValue("true");
                        FirebaseDatabase.getInstance().getReference().child("Tokens").child("User").child(snapshot.getValue().toString()).child("driver").setValue(FirebaseAuth.getInstance().getCurrentUser().getUid());
                        FirebaseDatabase.getInstance().getReference().child("Tokens").child("User").child(snapshot.getValue().toString()).child("name").setValue(name);
                        FirebaseDatabase.getInstance().getReference().child("Tokens").child("User").child(snapshot.getValue().toString()).child("Vehcile no").setValue(vehcile);
                        FirebaseDatabase.getInstance().getReference().child("Tokens").child("User").child(snapshot.getValue().toString()).child("phone no").setValue(phone);
                        dbef.child("phone number").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                user_phone=snapshot.getValue().toString();
                                FirebaseDatabase.getInstance().getReference().child("Tokens").child("User").child(user_uid).child("OTP").addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        OTP=snapshot.getValue().toString();
                                        dbef.child("pickup lat").addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {

                                                lat2= Double.parseDouble((snapshot.getValue().toString()));
                                                dbef.child("pickup long").addListenerForSingleValueEvent(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                        long2= Double.parseDouble((snapshot.getValue().toString()));
                                                        dbef.child("dropup lat").addListenerForSingleValueEvent(new ValueEventListener() {
                                                            @Override
                                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                                lat3= Double.parseDouble(snapshot.getValue().toString());
                                                                dbef.child("dropup long").addListenerForSingleValueEvent(new ValueEventListener() {
                                                                    @Override
                                                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                                        long3= Double.parseDouble(snapshot.getValue().toString());
                                                                        Intent intent = new Intent(com.hits.d2ddriver.HomeActivity.this, User_direction.class);
                                                                        Bundle b = new Bundle();
                                                                        b.putDouble("lat2", lat2);
                                                                        b.putDouble("long2", long2);
                                                                        b.putDouble("lat3", lat3);
                                                                        b.putDouble("long3", long3);
                                                                        b.putDouble("lat1",lat1);
                                                                        b.putDouble("long1",long1);
                                                                        b.putString("phone",user_phone);
                                                                        b.putString("otp",OTP);
                                                                        intent.putExtras(b);
                                                                        startActivity(intent);
                                                                        Toast.makeText(com.hits.d2ddriver.HomeActivity.this,"Accepted",Toast.LENGTH_SHORT).show();
                                                                        alertDialog.dismiss();

                                                                    }

                                                                    @Override
                                                                    public void onCancelled(@NonNull DatabaseError error) {

                                                                    }
                                                                });

                                                            }

                                                            @Override
                                                            public void onCancelled(@NonNull DatabaseError error) {

                                                            }
                                                        });
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError error) {

                                                    }
                                                });
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });

                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            }
        });
        Button bt1 = (Button) dialogView.findViewById(R.id.buttonreject);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbef.child("user id").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        FirebaseDatabase.getInstance().getReference().child("Tokens").child("User").child(snapshot.getValue().toString()).child("Accepted").setValue("false");
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
                Toast.makeText(com.hits.d2ddriver.HomeActivity.this,"Rejected",Toast.LENGTH_SHORT).show();
                alertDialog.dismiss();
            }
        });
    }
}
