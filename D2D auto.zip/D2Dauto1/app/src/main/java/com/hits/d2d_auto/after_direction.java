package com.hits.d2d_auto;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.hits.d2d_auto.R;

public class after_direction extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_direction);
        final int[] i = {0};
        while (i[0] <10){
            Handler handler=new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(after_direction.this,"abc",Toast.LENGTH_LONG).show();
                    i[0]++;
                }
            },3000);
        }
    }
}