package com.hits.d2d_auto;

import android.Manifest;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.Dash;
import com.google.android.gms.maps.model.Dot;
import com.google.android.gms.maps.model.Gap;
import com.google.android.gms.maps.model.JointType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PatternItem;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.RectangularBounds;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Maps_Home extends FragmentActivity implements OnMapReadyCallback {

    SupportMapFragment mapFragment;
    FusedLocationProviderClient client;
    GoogleMap googleMap1;
    private Geocoder geocoder;
    Marker marker1,marker2;
    private TransparentProgressDialog transparentProgressDialog;
    private String placename1,phone,vehcile,longitude,latitude,name,user_phone,user_uid,OTP,placename2;
    private TextView tvDistance, tvDuration,tvplacename,tvestfare;
    private LinearLayout directionDetailsLayout;
    LatLng curlatLng,latLng1,latLng2;
    AutocompleteSupportFragment autocompleteFragment,autocompleteFragment1;
    LocationRequest locationRequest;
    private static final int LOCATION_REQUEST_CODE = 100;
    private static Polyline polyline1,polyline2;
    Marker userLocationMarker;
    Circle userLocationAccuracyCircle;
    float Zoom=20;
    AppCompatButton Confirm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps__home);
        autocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment);
        autocompleteFragment.setCountries("IN");
        autocompleteFragment.setHint("Pickup Location");
        autocompleteFragment1 = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment2);
        autocompleteFragment1.setCountries("IN");
        autocompleteFragment1.setHint("Dropup Location");
        transparentProgressDialog = new TransparentProgressDialog(this, R.drawable.circle_loader, "");
        transparentProgressDialog.setCancelable(false);
        transparentProgressDialog.setCanceledOnTouchOutside(false);
        transparentProgressDialog.show();
        directionDetailsLayout = findViewById(R.id.Distance_direction);
        tvDistance = findViewById(R.id.Distance);
        tvDuration = findViewById(R.id.duration);
        tvplacename=findViewById(R.id.pl_name);
        tvestfare=findViewById(R.id.estimated_fare);
        Confirm=findViewById(R.id.confirm);
        mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.google_map);
        mapFragment.onCreate(savedInstanceState);
        mapFragment.getMapAsync(this);
        geocoder = new Geocoder(this);
        client = LocationServices.getFusedLocationProviderClient(this);
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(200);
        locationRequest.setFastestInterval(200);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ActivityCompat.checkSelfPermission(Maps_Home.this
                , Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
        }
        else {
            ActivityCompat.requestPermissions(Maps_Home.this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 44);
        }
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyDx5-n2oQNBf9z73zM8bB-t1Zr24mC-7xs");
        }
        autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));
        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NotNull Place place) {
                setup();
                try {
                    List<Address> addresses = geocoder.getFromLocation(place.getLatLng().latitude, place.getLatLng().longitude, 1);
                    if (addresses.size() > 0) {
                        Address address = addresses.get(0);
                        String streetAddress = address.getAddressLine(0);
                        MarkerOptions options = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.pin)).position(place.getLatLng()).title(place.getName()+","+streetAddress).draggable(true);
                        googleMap1.setOnMarkerDragListener(dragmarker);
                        if (marker1 != null){
                            marker1.remove();
                        }
                        else {
                            Toast.makeText(Maps_Home.this,"Long Tap on Marker to Drag and Drop this Marker for more accurate results",Toast.LENGTH_LONG).show();
                        }
                        marker1 = googleMap1.addMarker(options);
                        marker1.setDraggable(true);
                        latLng1=place.getLatLng();
                        googleMap1.setOnMarkerDragListener(dragmarker);
                        CameraPosition cameraPosition = new CameraPosition.Builder()
                                .target(place.getLatLng())
                                .zoom(19)
                                .tilt(0)
                                .build();
                        googleMap1.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                        placename1=place.getName();
                        if(polyline2!=null)
                            polyline2.remove();
                        if(polyline2!=null){
                            polyline(latLng1,latLng2,polyline1);
                        }
                        else{
                            polyline(latLng1,curlatLng,polyline1);
                        }
                        //if(marker1!=null&&marker2!=null)
                        //getDirections(latLng1,latLng2);
                        //googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng1_mid, Zoom));
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
            @Override
            public void onError(@NotNull Status status) {
            }
        });
        autocompleteFragment1.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));
        autocompleteFragment1.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NotNull Place place) {
                setup();
                try {
                    List<Address> addresses = geocoder.getFromLocation(place.getLatLng().latitude, place.getLatLng().longitude, 1);
                    if (addresses.size() > 0) {
                        Address address = addresses.get(0);
                        String streetAddress = address.getAddressLine(0);
                        MarkerOptions options = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.pin)).position(place.getLatLng()).title(place.getName()+","+streetAddress).draggable(true);
                        googleMap1.setOnMarkerDragListener(dragmarker);
                        if (marker2 != null){
                            marker2.remove();
                        }
                        else {
                            Toast.makeText(Maps_Home.this,"Long Tap on Marker to Drag and Drop this Marker for more accurate results",Toast.LENGTH_LONG).show();
                        }
                        marker2 = googleMap1.addMarker(options);
                        marker2.setDraggable(true);
                        latLng2=place.getLatLng();
                        googleMap1.setOnMarkerDragListener(dragmarker);
                        CameraPosition cameraPosition = new CameraPosition.Builder()
                                .target(place.getLatLng())
                                .zoom(19)
                                .tilt(0)
                                .build();
                        googleMap1.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                        placename2=place.getName();
                        //latLng2_mid=LatLngBounds.builder().include(latLng2).include(curlatLng).build().getCenter();
                       // googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng2_mid, Zoom));
                        if(polyline1!=null)
                            polyline1.remove();
                        if(polyline1!=null){
                        polyline(latLng2,latLng1,polyline2);

                        }
                        else {
                            polyline(latLng2,curlatLng,polyline2);
                        }
                        //if(marker1!=null&&marker2!=null)
                        //getDirections(latLng1,latLng2);
                        //googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng2_mid, Zoom));
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
            @Override
            public void onError(@NotNull Status status) {
            }
        });
    }
    public GoogleMap.OnMarkerDragListener dragmarker = new GoogleMap.OnMarkerDragListener() {
        @Override
        public void onMarkerDragStart(Marker marker) {
            setup();
            Toast.makeText(Maps_Home.this,"Tap on Marker after Drag End to Update Location",Toast.LENGTH_LONG).show();
        }

        @Override
        public void onMarkerDrag(Marker marker) {

        }

        @Override
        public void onMarkerDragEnd(Marker marker) {
            if(marker.equals(marker1)) {
                LatLng latLng = marker.getPosition();
                latLng1 = latLng;
                try {
                    List<Address> addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
                    if (addresses.size() > 0) {

                        Address address = addresses.get(0);
                        String streetAddress = address.getAddressLine(0);
                        placename1 = streetAddress;
                        marker.setTitle(streetAddress);
                        if(polyline2!=null)
                        polyline2.remove();
                        if(polyline2!=null){
                           // latLng1_mid = LatLngBounds.builder().include(latLng1).include(latLng2).build().getCenter();
                            polyline(latLng1, latLng2,polyline1);
                        }
                        else {
                            //latLng1_mid = LatLngBounds.builder().include(latLng1).include(curlatLng).build().getCenter();
                            polyline(latLng1, curlatLng,polyline1);
                        }
                        //googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng1_mid, Zoom));
                        autocompleteFragment.setText(streetAddress);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(marker.equals(marker2)){
                LatLng latLng = marker.getPosition();
                latLng2=latLng;
                try {
                    List<Address> addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
                    if (addresses.size() > 0) {
                        Address address = addresses.get(0);
                        String streetAddress = address.getAddressLine(0);
                        placename2=streetAddress;
                        if(polyline1!=null)
                            polyline1.remove();
                        marker.setTitle(streetAddress);
                        if(polyline1!=null){
                            //latLng1_mid = LatLngBounds.builder().include(latLng1).include(latLng2).build().getCenter();
                            polyline(latLng2, latLng1,polyline2);
                        }
                        else {
                            //latLng2_mid = LatLngBounds.builder().include(latLng1).include(curlatLng).build().getCenter();
                            polyline(latLng2, curlatLng,polyline2);
                        }
                        //googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng2_mid, Zoom));
                        autocompleteFragment.setText(streetAddress);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    };


    @Override
    public void onMapReady(GoogleMap googleMap) {
        googleMap1 = googleMap;
        googleMap1.setBuildingsEnabled(true);
        //googleMap1.getUiSettings().setCompassEnabled(true);
        //googleMap1.setMyLocationEnabled(true);
        googleMap1.getUiSettings().setMapToolbarEnabled(false);
        googleMap1.getUiSettings().setMyLocationButtonEnabled(false);
        //enable_location();
    }
    public void polyline(LatLng latLng1,LatLng latLng2,Polyline polyline){
        LatLng latLng_mid;
        List<PatternItem> pattern = Arrays.<PatternItem>asList(new Dot(), new Gap(20), new Dash(30), new Gap(20));
        PolylineOptions polylineOptions=new PolylineOptions();
        polylineOptions.clickable(false).geodesic(true).jointType(JointType.ROUND).pattern(pattern).color(Color.argb(90,255,0,0))
                .add(latLng1,latLng2);
        Direction_ditance(latLng1,latLng2);
        if(polyline!=null){
            if(polyline==(polyline1)){
                polyline1.remove();
            }
            else{
                polyline2.remove();
            }
        }
        if(polyline==(polyline1)){
            polyline1= googleMap1.addPolyline(polylineOptions);
        }
        else{
            polyline2=googleMap1.addPolyline(polylineOptions);
        }
        latLng_mid=LatLngBounds.builder().include(latLng1).include(latLng2).build().getCenter();
        googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng_mid, Zoom));
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 44) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                checkSettingsAndStartLocationUpdates();
                //getCurrentLocation();
                //enable_location();
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
//            getLastLocation();
            checkSettingsAndStartLocationUpdates();
        } else {
            askLocationPermission();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopLocationUpdates();
    }

    private void checkSettingsAndStartLocationUpdates() {
        LocationSettingsRequest request = new LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest).build();
        SettingsClient client = LocationServices.getSettingsClient(this);

        Task<LocationSettingsResponse> locationSettingsResponseTask = client.checkLocationSettings(request);
        locationSettingsResponseTask.addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                startLocationUpdates();
            }
        });
        locationSettingsResponseTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if (e instanceof ResolvableApiException) {
                    ResolvableApiException apiException = (ResolvableApiException) e;
                    try {
                        apiException.startResolutionForResult(Maps_Home.this, 1001);
                    } catch (IntentSender.SendIntentException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
    }

    private void askLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            }
        }
    }

    LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            super.onLocationResult(locationResult);
            if (googleMap1 != null) {
                setUserLocationMarker(locationResult.getLastLocation());
            }
        }
    };
    private LatLngBounds setBounds(Location location, int mDistanceInMeters ){
        double latRadian = Math.toRadians(location.getLatitude());

        double degLatKm = 110.574235;
        double degLongKm = 110.572833 * Math.cos(latRadian);
        double deltaLat = mDistanceInMeters / 1000.0 / degLatKm;
        double deltaLong = mDistanceInMeters / 1000.0 / degLongKm;

        double minLat = location.getLatitude() - deltaLat;
        double minLong = location.getLongitude() - deltaLong;
        double maxLat = location.getLatitude() + deltaLat;
        double maxLong = location.getLongitude() + deltaLong;
        return new LatLngBounds(new LatLng(minLat, minLong), new LatLng(maxLat, maxLong));
    }

    private void setUserLocationMarker(Location location) {
        autocompleteFragment.setLocationBias(RectangularBounds.newInstance(setBounds(location,5000)));
        autocompleteFragment1.setLocationBias(RectangularBounds.newInstance(setBounds(location,5000)));
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        curlatLng=latLng;
        if (userLocationMarker == null) {
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(latLng);
            markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.cursor));
            markerOptions.rotation(location.getBearing());
            markerOptions.anchor((float) 0.5, (float) 0.5);
            userLocationMarker = googleMap1.addMarker(markerOptions);
            googleMap1.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 19));
            transparentProgressDialog.dismiss();
        } else {
            userLocationMarker.setPosition(latLng);
            userLocationMarker.setRotation(location.getBearing());
            /*if (polyline!=null){
                polyline(curlatLng,latLng1);
            }*/
        }
        if (userLocationAccuracyCircle == null) {
            CircleOptions circleOptions = new CircleOptions();
            circleOptions.center(latLng);
            circleOptions.strokeWidth((float) 0.5);
            circleOptions.strokeColor(Color.argb(100, 0, 30, 255));
            circleOptions.fillColor(Color.argb(32, 0, 30, 255));
            circleOptions.radius(location.getAccuracy());
            userLocationAccuracyCircle = googleMap1.addCircle(circleOptions);
        } else {
            userLocationAccuracyCircle.setCenter(latLng);
            userLocationAccuracyCircle.setRadius(location.getAccuracy());
        }
    }


    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        client.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
    }

    private void stopLocationUpdates() {
        client.removeLocationUpdates(locationCallback);
    }

    public void Direction(View view) {
        Intent intent = new Intent(Maps_Home.this,Direction.class);
        Bundle b = new Bundle();
        b.putDouble("lat2", latLng2.latitude);
        b.putDouble("long2", latLng2.longitude);
        b.putDouble("lat1",latLng1.latitude);
        b.putDouble("long1",latLng1.longitude);
        b.putString("placename",placename2);
        intent.putExtras(b);
        startActivity(intent);
    }

    public void current(View view) {
        googleMap1.moveCamera(CameraUpdateFactory.newLatLngZoom(curlatLng, 19));
    }

    public void Direction_ditance(LatLng latLng1,LatLng latLng2) {
        //directionDetailsLayout.setVisibility(View.VISIBLE);
        float[] results=new float[10];
        Location.distanceBetween(latLng1.latitude,latLng1.longitude,latLng2.latitude,latLng2.longitude,results);
        tvDistance.setText(getFormattedDistance(results[0]));
        tvDuration.setText(getFormattedDuration(results[0]*0.25));
        if(placename2!=null)
        tvplacename.setText(placename2);
        else
            tvplacename.setText(placename1);
    }
    private String getFormattedDistance(double distance) {
        if((distance<=500))
            Zoom= (float) 18;
        if((distance<=1000)&&(distance>500))
            Zoom= (float) 16.5;
        if((distance<=1500)&&(distance>1000))
            Zoom= (float) 16;
        if((distance<=2000)&&(distance>1500))
            Zoom= (float) 15.7;
        if((distance<=2500)&&(distance>2000))
            Zoom= (float) 15.2;
        if((distance<=3000)&&(distance>2500))
            Zoom= (float) 14.5;
        if((distance<=3500)&&(distance>3000))
            Zoom= (float) 14;
        if((distance<=4000)&&(distance>3000))
            Zoom= (float) 14.5;
        if((distance<=5000)&&(distance>4000))
            Zoom= (float) 14;
        if((distance<=6000)&&(distance>5000))
            Zoom= (float) 13;
        if((distance<=7000)&&(distance>6000))
            Zoom= (float) 12.2;
        if((distance<=8500)&&(distance>7000))
            Zoom= (float) 11.6;
        if((distance<=10000)&&(distance>8500))
            Zoom= (float) 11;
        if((distance<=20000)&&(distance>10000))
            Zoom= (float) 10;
        if((distance<=35000)&&(distance>20000))
            Zoom= (float) 9.5;
        if((distance<=50000)&&(distance>35000))
            Zoom= (float) 9;
        if((distance<=100000)&&(distance>50000))
            Zoom= (float) 8;
        if((distance>100000))
            Zoom= (float) 6;
        if ((distance / 1000) < 1) {
            DecimalFormat decimalFormat = new DecimalFormat("#.#");
            return decimalFormat.format(distance) + "mtr.";
        }
        DecimalFormat decimalFormat = new DecimalFormat("#.#");
        return decimalFormat.format(distance / 1000) + "Km.";
    }
    private String getFormattedDuration(double duration) {
        long min = (long) (duration % 3600 / 60);
        long hours = (long) (duration % 86400 / 3600);
        long days = (long) (duration / 86400);
        if (days > 0L) {
            return days + " " + (days > 1L ? "Days" : "Day") + " " + hours + " " + "hr" + (min > 0L ? " " + min + " " + "min." : "");
        } else {
            return hours > 0L ? hours + " " + "hr" + (min > 0L ? " " + min + " " + "min" : "") : min + " " + "min.";
        }
    }

    public void Set_current(View view) {
        setup();
        latLng1=curlatLng;
        if (marker1 != null) {
            marker1.remove();
        }
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng1);
        markerOptions.draggable(true);
        markerOptions.title("Current Location");
        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.pin));
        //markerOptions.rotation(location.getBearing());
        markerOptions.anchor((float) 0.5, (float) 0.5);
        marker1 = googleMap1.addMarker(markerOptions);
        googleMap1.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng1, 19));
        autocompleteFragment.setText("Current Location");
        if(polyline2!=null)
            polyline2.remove();
        if(polyline2!=null){
            // latLng1_mid = LatLngBounds.builder().include(latLng1).include(latLng2).build().getCenter();
            polyline(latLng1, latLng2,polyline1);
        }
        else {
            //latLng1_mid = LatLngBounds.builder().include(latLng1).include(curlatLng).build().getCenter();
            polyline(latLng1,curlatLng,polyline1);
        }
    }

    public void show_path(View view) {
        if(marker1==null || marker2== null){
            Toast.makeText(this,"location Field Empty",Toast.LENGTH_SHORT).show();
        }
        else {
            Confirm.setVisibility(View.GONE);
            getDirections(latLng1,latLng2);
        }
    }
    public void setup(){
        directionDetailsLayout.setVisibility(View.GONE);
        Confirm.setVisibility(View.VISIBLE);
    }

    public void Book(View view) {
    }
    private void getDirections(LatLng latLng1, LatLng latLng2) {
        //googleMap1.clear();
       // MarkerOptions options = new MarkerOptions().position(latLng2).title(placename);
        //googleMap1.addMarker(options);

        directionDetailsLayout.setVisibility(View.VISIBLE);
        String url = getDirectionsUrl(latLng1, latLng2);
        com.hits.d2d_auto.DownloadTask1 downloadTask = new com.hits.d2d_auto.DownloadTask1();
        downloadTask.map(googleMap1,tvDuration,tvDistance,tvestfare);
        downloadTask.execute(url);
        directionDetailsLayout.setVisibility(View.VISIBLE);
    }
    private String getDirectionsUrl(LatLng origin,LatLng dest){
        String str_origin = "origin="+origin.latitude+","+origin.longitude;
        String str_dest = "destination="+dest.latitude+","+dest.longitude;
        String sensor = "sensor=true";
        String parameters = str_origin+"&"+str_dest+"&"+sensor;
        String output = "json";
        String url = "https://maps.googleapis.com/maps/api/directions/"+output+"?"+parameters+"&mode=driving&dir_action=navigate&optimize:true&key=AIzaSyDx5-n2oQNBf9z73zM8bB-t1Zr24mC-7xs";
        return url;
    }

    public void setup(View view) {
        setup();
    }
}

class DownloadTask1 extends AsyncTask<String, Void, String> {
    GoogleMap googleMap;
    TextView distance,duration,fare;
    @Override
    protected String doInBackground(String... url) {
        String data = "";
        try{
            data = downloadUrl(url[0]);
        }catch(Exception e){
        }
        return data;
    }
    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        com.hits.d2d_auto.ParserTask1 parserTask = new com.hits.d2d_auto.ParserTask1();
        parserTask.map(googleMap,distance,duration,fare);
        parserTask.execute(result);

    }
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try{
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();
            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));
            StringBuffer sb = new StringBuffer();
            String line = "";
            while( ( line = br.readLine()) != null){
                sb.append(line);
            }
            data = sb.toString();
            br.close();
        }catch(Exception e){
        }finally{
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    public void map(GoogleMap googleMap1,TextView Duration,TextView Distance,TextView Fare) {
        googleMap=googleMap1;
        distance=Distance;
        duration=Duration;
        fare=Fare;
    }
}

class ParserTask1 extends AsyncTask<String, Integer, List<List<HashMap<String,String>>> >{
    GoogleMap map;
    TextView Distance,Duration,fare;
    PolylineOptions lineOptions;

    @Override
    protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

        JSONObject jObject;
        List<List<HashMap<String, String>>> routes = null;

        try{
            jObject = new JSONObject(jsonData[0]);
            DirectionsJSONParser parser = new DirectionsJSONParser();
            routes = parser.parse(jObject);
        }catch(Exception e){
            e.printStackTrace();
        }
        return routes;
    }
    @Override
    protected void onPostExecute(List<List<HashMap<String, String>>> result) {
        ArrayList points = null;
        String distance = "";
        String duration = "";

        if(result.size()<1){
            return;
        }
        for(int i=0;i<result.size();i++){
            points = new ArrayList();
            lineOptions = new PolylineOptions();
            List<HashMap<String, String>> path = result.get(i);

            for(int j=0;j <path.size();j++){
                HashMap<String,String> point = path.get(j);

                if(j==0){
                    distance = (String)point.get("distance");
                    continue;
                }else if(j==1){
                    duration = (String)point.get("duration");
                    continue;
                }

                double lat = Double.parseDouble(point.get("lat"));
                double lng = Double.parseDouble(point.get("lng"));
                LatLng position = new LatLng(lat, lng);

                points.add(position);
            }
            lineOptions.addAll(points);
            lineOptions.width(12);
            lineOptions.color(Color.RED);
        }
        String[] distance1;
        if(distance.contains("t")){
            distance1=distance.split("m");
            fare.setText(String.valueOf (Float.parseFloat(distance1[0])*.01));
        }
        else{
            distance1=distance.split("k");
            fare.setText(String.valueOf (Float.parseFloat(distance1[0])*10));
        }
        Distance.setText(distance);
        Duration.setText(duration);
        //fare.setText("knsk");
       // polyline=map.addPolyline(lineOptions);
    }
    public void map(GoogleMap googleMap,TextView distance,TextView duration,TextView Fare) {
        map=googleMap;
        Distance=distance;
        Duration=duration;
        fare=Fare;
    }
}
