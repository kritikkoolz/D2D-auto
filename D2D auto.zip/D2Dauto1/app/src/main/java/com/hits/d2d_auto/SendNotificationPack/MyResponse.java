package com.hits.d2d_auto.SendNotificationPack;

public class MyResponse {
    public int success;

}
