package com.hits.d2d_auto;

import android.app.Application;

import com.mapbox.mapboxsdk.MapmyIndia;
import com.mmi.services.account.MapmyIndiaAccountManager;

public class MapMyIndia extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        MapmyIndiaAccountManager.getInstance().setRestAPIKey(getRestAPIKey());
        MapmyIndiaAccountManager.getInstance().setMapSDKKey(getMapSDKKey());
        MapmyIndiaAccountManager.getInstance().setAtlasClientId(getAtlasClientId());
        MapmyIndiaAccountManager.getInstance().setAtlasClientSecret(getAtlasClientSecret());
        MapmyIndiaAccountManager.getInstance().setAtlasGrantType(getAtlasGrantType());
        MapmyIndia.getInstance(this);
    }
    public String getAtlasClientId() {
        return "33OkryzDZsKMIVXYxZv27R-kTCnvxW9l3qgeM97mXrUWHdKrcPcmrEx1seTg3CPD0YMy-qZgQyLE-fIf0EQ3b9yk7JWRIhV_ccBAXBy43yAW2qjdteYFfw==";
    }
    public String getAtlasClientSecret() {
        return "lrFxI-iSEg_ebbmJ289T64YVp1Jqs_2rp1-pX1BgxP_yEPpq1IpcyjqRTWjKXT40k9PUCeOBX-x8x4LRlPSALyjEPfEhS_buybK6vtzVMSeNkvN6KA3I-lfYczWyyyUF";
    }
    public String getAtlasGrantType() {
        return "client_credentials";
    }

    public String getMapSDKKey() {
        return "ot3jk7tmg7y1uxzr9r2y18nvdyn3oltd";
    }

    public String getRestAPIKey() {
        return "oy8dvf5a3xed8cmzwcsyqw6pjtygqeme";
    }

}