package com.hits.d2d_auto;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private Animation bottom_anim;
    private TextView TV2;
    private Handler handler;
    private FirebaseUser user;
    private String user_id;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        user=FirebaseAuth.getInstance().getCurrentUser();
        handler = new Handler();
        handler.postDelayed(new Runnable(){
            @Override
            public void run() {
                if (user != null) {
                    user_id = user.getUid();
                    DatabaseReference dbref = FirebaseDatabase.getInstance().getReference().child("D2D auto").child(user_id).child("Information");
                    dbref.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if (dataSnapshot.hasChildren()) {
                                Intent intent1 = new Intent(MainActivity.this, Maps_Home.class);
                                intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent1);
                                finish();
                            } else {
                                Intent intent = new Intent(MainActivity.this, Register.class);
                                Toast.makeText(MainActivity.this, "Please add some important personal info..", Toast.LENGTH_SHORT).show();
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                                finish();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                } else {
                    Intent intent = new Intent(MainActivity.this, Intro_slider.class);
                    startActivity(intent);
                    finish();
                }
            }
    },3000);


        bottom_anim = AnimationUtils.loadAnimation(this, R.anim.bottom_to_top);
        bottom_anim.setDuration(2000);
        TV2 = (TextView) findViewById(R.id.tv2);
        TV2.setAnimation(bottom_anim);
    }
}