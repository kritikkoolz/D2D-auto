package com.e_sathi.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Manage_Drivers extends AppCompatActivity {
    NavigationView nav;
    FirebaseUser user;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;
    ListView listView;
    Custom_adapter custom_adapter;
    int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage__drivers);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Intent intent=getIntent();
        i=intent.getIntExtra("Drivers",0);
        user= FirebaseAuth.getInstance().getCurrentUser();
        nav=(NavigationView)findViewById(R.id.navmenu);
        View headerView = nav.getHeaderView(0);
        TextView navUsername = (TextView)headerView.findViewById(R.id.email_nav);
        navUsername.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail().toString());
        drawerLayout=(DrawerLayout)findViewById(R.id.drawer);
        toggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
            {
                switch (menuItem.getItemId())
                {
                    case R.id.dashboard :
                        Intent intent1 =new Intent(Manage_Drivers.this,HomeActivity.class);
                        startActivity(intent1);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.manage_drivers :
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.manage_coupon :
                        Intent intent2 =new Intent(Manage_Drivers.this,Manage_Coupons.class);
                        startActivity(intent2);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.manage_admin :
                        Intent intent =new Intent(Manage_Drivers.this,Manage_Admin.class);
                        startActivity(intent);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.manage_rides:
                        Intent intent3 =new Intent(Manage_Drivers.this,Manage_Rides.class);
                        startActivity(intent3);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.manage_riders :
                        Intent intent4 =new Intent(Manage_Drivers.this,Manage_riders.class);
                        startActivity(intent4);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.view_profile:
                        Intent intent5 =new Intent(Manage_Drivers.this,View_Profile.class);
                        startActivity(intent5);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.sign_out :
                        confirm confirm1=new confirm(Manage_Drivers.this);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        confirm1.sign_out();
                        break;
                    case R.id.change_password :
                        confirm confirm2=new confirm(Manage_Drivers.this);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        confirm2.forgot_password();
                        break;
                }

                return true;
            }
        });
        ArrayList<String> name = new ArrayList<String>();
        ArrayList<String> phone = new ArrayList<String>();
        ArrayList<String> email = new ArrayList<String>();
        ArrayList<String> status = new ArrayList<String>();
        ArrayList<String> alloted = new ArrayList<String>();
        ArrayList<String> commission = new ArrayList<String>();
        ArrayList<String> banned = new ArrayList<String>();
        ArrayList<String> doj = new ArrayList<String>();
        DatabaseReference dbref= FirebaseDatabase.getInstance().getReference().child("E-Sathi_Driver");
        dbref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                    DatabaseReference dbref2=FirebaseDatabase.getInstance().getReference().child("E-Sathi_Driver").child(dataSnapshot.getKey().toString()).child("Information");
                    dbref2.child("Username").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            name.add(snapshot.getValue().toString());
                            dbref2.child("Phone").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    phone.add(snapshot.getValue().toString());
                                    dbref2.child("Email").addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            email.add(snapshot.getValue().toString());
                                            dbref2.child("Live").addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                    status.add(snapshot.getValue().toString());
                                                    dbref2.child("Alloted").addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                            alloted.add(snapshot.getValue().toString());
                                                            dbref2.child("Banned").addListenerForSingleValueEvent(new ValueEventListener() {
                                                                @Override
                                                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                                    banned.add(snapshot.getValue().toString());
                                                                    dbref2.child("DOJ").addListenerForSingleValueEvent(new ValueEventListener() {
                                                                        @Override
                                                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                                            doj.add(snapshot.getValue().toString());
                                                                            dbref2.child("Commission").addListenerForSingleValueEvent(new ValueEventListener() {
                                                                                @Override
                                                                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                                                    commission.add(snapshot.getValue().toString());
                                                                                    if(commission.size()==i){
                                                                                    Toast.makeText(Manage_Drivers.this,String.valueOf(commission.get(1)),Toast.LENGTH_LONG).show();
                                                                                    custom_adapter = new Custom_adapter(Manage_Drivers.this,name,phone,status,alloted,email,banned,commission,doj);
                                                                                    listView = (ListView) findViewById(R.id.drivers);
                                                                                    listView.setAdapter(custom_adapter);
                                                                                    }
                                                                                }
                                                                                @Override
                                                                                public void onCancelled(@NonNull DatabaseError error) {

                                                                                }
                                                                            });
                                                                        }

                                                                        @Override
                                                                        public void onCancelled(@NonNull DatabaseError error) {

                                                                        }
                                                                    });
                                                                }

                                                                @Override
                                                                public void onCancelled(@NonNull DatabaseError error) {

                                                                }
                                                            });
                                                        }

                                                        @Override
                                                        public void onCancelled(@NonNull DatabaseError error) {

                                                        }
                                                    });
                                                }

                                                @Override
                                                public void onCancelled(@NonNull DatabaseError error) {

                                                }
                                            });
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }
}