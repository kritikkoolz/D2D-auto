package com.e_sathi.admin;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private TextInputLayout e1;
    private TextInputLayout e2;
    private String email;
    private ProgressDialog progress;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private String user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.email);
        e2=findViewById(R.id.password);
        TextInputEditText e21 = findViewById(R.id.password_ed);
        e21.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > e2.getCounterMaxLength())
                    e2.setError("Max character length is " + e2.getCounterMaxLength());
                else
                    e2.setError(null);
            }
        });
        auth = FirebaseAuth.getInstance();
        user= FirebaseAuth.getInstance().getCurrentUser();
        progress = new ProgressDialog(this);
        progress.setMessage("Signing In...");
        progress.setCanceledOnTouchOutside(false);
        progress.setCancelable(false);

    }

    public void login(View view){
        email = e1.getEditText().getText().toString();
        String password = e2.getEditText().getText().toString();
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Empty Credentials", Toast.LENGTH_LONG).show();
        } else if (password.length() < 8) {
            Toast.makeText(this, "Password Must Be Of Length 8", Toast.LENGTH_LONG).show();
        }
        else{
            login_user(email, password);
            progress.show();
        }

    }
    private void login_user(final String email, String password) {
        auth.signInWithEmailAndPassword(email, password).addOnSuccessListener(MainActivity.this, authResult -> {
            user = FirebaseAuth.getInstance().getCurrentUser();
            user_id=user.getUid();
            DatabaseReference dbref;
            dbref=FirebaseDatabase.getInstance().getReference().child("Admin").child(user_id);
            dbref.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.getValue().toString().equals("Super Admin")){
                        Intent intent = new Intent(MainActivity.this,HomeActivity.class);
                        startActivity(intent);
                        finish();
                    }
                    else {
                        Intent intent = new Intent(MainActivity.this,HomeActivity.class);
                        startActivity(intent);
                        finish();
                    }
                    progress.dismiss();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }).addOnFailureListener(MainActivity.this, e -> {
            Toast.makeText(MainActivity.this,"Invalid Credentials",Toast.LENGTH_SHORT).show();
            progress.dismiss();
        });
    }

    public void forgot_password(View view) {
        final AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
        alert.setTitle("Forget Password ?");
        alert.setIcon(R.drawable.forgot_password);
        alert.setMessage("Confirm mail to get password reset link.");
        final EditText input = new EditText(this);
        alert.setView(input);
        alert.setPositiveButton("Submit", (dialog, whichButton) -> {
            if(TextUtils.isEmpty(input.getText().toString())){
                Toast.makeText(MainActivity.this,"Empty Field",Toast.LENGTH_LONG).show();
            }
            else {
                auth.sendPasswordResetEmail(input.getText().toString()).addOnSuccessListener(aVoid -> {
                    email=input.getText().toString();
                    showCustomDialog_tick1();
                }).addOnFailureListener(e -> Toast.makeText(MainActivity.this,"Password Reset Email Sent failed",Toast.LENGTH_SHORT).show());
            }
        });
        alert.setNegativeButton("Cancel", (dialog, whichButton) -> Toast.makeText(MainActivity.this,"Thank You",Toast.LENGTH_SHORT).show());
        AlertDialog alertDialog=alert.create();
        alertDialog.show();
        alertDialog.setCancelable(false);
        alertDialog.setCanceledOnTouchOutside(false);
    }
    private void showCustomDialog_tick1() {
        ViewGroup viewGroup = findViewById(android.R.id.content);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.tick_custom, viewGroup, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
        alertDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.setCancelable(false);
        TextView tv=dialogView.findViewById(R.id.customtv);
        tv.setText(getResources().getString(R.string.password_reset_email_sent_successfully));
        TextView tv2=dialogView.findViewById(R.id.customtv1);
        tv2.setText(getResources().getString(R.string.change_password_and_then_login_again));
        AppCompatButton bt = dialogView.findViewById(R.id.buttonOk);
        bt.setOnClickListener(v -> {
            alertDialog.dismiss();
            Toast.makeText(MainActivity.this,"Thank You",Toast.LENGTH_LONG).show();
        });
        AppCompatButton bt1 = dialogView.findViewById(R.id.buttonsent);
        bt1.setOnClickListener(v -> {
            alertDialog.dismiss();
            auth.sendPasswordResetEmail(email).addOnSuccessListener(MainActivity.this, aVoid -> showCustomDialog_tick1());
        });
    }

    @Override
    protected void onStart() {
        if(FirebaseAuth.getInstance().getCurrentUser()!=null){
            Intent intent=new Intent(MainActivity.this,HomeActivity.class);
            startActivity(intent);
            finish();
        }
        super.onStart();
    }
}