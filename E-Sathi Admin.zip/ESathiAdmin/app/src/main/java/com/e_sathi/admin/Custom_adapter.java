package com.e_sathi.admin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;

import java.util.ArrayList;

public class Custom_adapter extends BaseAdapter{
        ArrayList<String> name;
    ArrayList<String> phone;
    ArrayList<String> Doj;
    ArrayList<String> Banned;
    ArrayList<String> Status;
    ArrayList<String> Alloted;
    ArrayList<String> Email;
    ArrayList<String> Commission;
        Context context;
        private static LayoutInflater inflater=null;

        public Custom_adapter(Manage_Drivers mainActivity, ArrayList<String> Name, ArrayList<String> Phone, ArrayList<String> status, ArrayList<String> alloted, ArrayList<String> email, ArrayList<String> Banned, ArrayList<String> commission, ArrayList<String> doj) {
// TODO Auto-generated constructor stub
            context=mainActivity;
            this.Alloted=alloted;
            this.Doj=doj;
            this.name=Name;
            this.phone=Phone;
            this.Status=status;
            this.Commission=commission;
            this.Email=email;
            this.Banned=Banned;
            inflater = ( LayoutInflater )context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
// TODO Auto-generated method stub
            return name.size();
        }

        @Override
        public Object getItem(int position) {
// TODO Auto-generated method stub
            return position;
        }

        @Override
        public long getItemId(int position) {
// TODO Auto-generated method stub
            return position;
        }

        public class Holder
        {
            TextView name,phone,sno,email,status,commission,doj;
            SwitchCompat banned;
            ImageView dot;
        }
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
// TODO Auto-generated method stub
            Holder holder = new Holder();
            View view;
            view = inflater.inflate(R.layout.driver_cards,null);
            holder.dot=(ImageView) view.findViewById(R.id.dot);
            holder.name= (TextView) view.findViewById(R.id.name_name);
            holder.phone= (TextView) view.findViewById(R.id.phone_phone);
            holder.status= (TextView) view.findViewById(R.id.status_status);
            holder.email= (TextView) view.findViewById(R.id.email2);
            holder.sno= (TextView) view.findViewById(R.id.Sno_Sno);
            holder.commission= (TextView) view.findViewById(R.id.commisson2);
            holder.doj= (TextView) view.findViewById(R.id.doj2);
            holder.name.setText(name.get(position));
            holder.phone.setText(phone.get(position));
            if(!Email.get(position).equals("")){
                holder.email.setText(Email.get(position));
            }
            if(Alloted.get(position).equals("true"))
                holder.dot.setImageResource(R.drawable.green);
            else
                holder.dot.setImageResource(R.drawable.red);
            holder.commission.setText(Commission.get(position));
            holder.sno.setText(String.valueOf(position+1));
            holder.doj.setText(Doj.get(position));
            holder.status.setText(Status.get(position));
            return view;
        }
    }

