package com.e_sathi.admin;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.TextUtils;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
public class confirm extends AppCompatActivity {
    private Context context;
    private String email;

    public confirm(Context context){
        this.context=context;
    }
    public void sign_out(){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Do you really want to Signout ?");
        builder.setTitle("Signout");
        builder.setCancelable(false);
        builder.setIcon(R.drawable.ic_signout);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                FirebaseAuth.getInstance().signOut();
                Intent intent1 = new Intent(context,MainActivity.class);
                startActivity(intent1);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        AlertDialog alertDialog = builder.create();
        try {
            alertDialog.show();
            alertDialog.setCanceledOnTouchOutside(false);
            alertDialog.setCancelable(false);
        }
        catch (WindowManager.BadTokenException e) {
        }

    }
    public void forgot_password() {
        final AlertDialog.Builder alert = new AlertDialog.Builder(context);
        alert.setTitle("Change Password ?");
        alert.setIcon(R.drawable.forgot_password);
        alert.setMessage("Confirm mail to get password reset link.");
        final EditText input = new EditText(context);
        alert.setView(input);
        alert.setPositiveButton("Submit", (dialog, whichButton) -> {
            if(TextUtils.isEmpty(input.getText().toString())){
                Toast.makeText(context,"Empty Field",Toast.LENGTH_LONG).show();
            }
            else {
                FirebaseAuth.getInstance().sendPasswordResetEmail(input.getText().toString()).addOnSuccessListener(aVoid -> {
                    email=input.getText().toString();
                    Toast.makeText(context,"Password Reset Email Sent Successfully..\nNow check your inbox",Toast.LENGTH_LONG).show();
                }).addOnFailureListener(e -> Toast.makeText(context,"Password Reset Email Sent failed",Toast.LENGTH_SHORT).show());
            }
        });
        alert.setNegativeButton("Cancel", (dialog, whichButton) -> Toast.makeText(context,"Thank You",Toast.LENGTH_SHORT).show());
        AlertDialog alertDialog=alert.create();
        alertDialog.show();
        alertDialog.setCancelable(false);
        alertDialog.setCanceledOnTouchOutside(false);
    }
}
