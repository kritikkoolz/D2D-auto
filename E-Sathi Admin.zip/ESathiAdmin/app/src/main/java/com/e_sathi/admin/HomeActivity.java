package com.e_sathi.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.time.Year;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

public class HomeActivity extends AppCompatActivity {
    TextView textView1,textView2,textView3,textView4,textView5,textView6;
    DatabaseReference dbref;
    List alist1,alist2;
    int i=0,j=0;
    NavigationView nav;
    FirebaseUser user;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        user=FirebaseAuth.getInstance().getCurrentUser();
        nav=(NavigationView)findViewById(R.id.navmenu);
        View headerView = nav.getHeaderView(0);
        TextView navUsername = (TextView)headerView.findViewById(R.id.email_nav);
        navUsername.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail().toString());
        drawerLayout=(DrawerLayout)findViewById(R.id.drawer);
        toggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
            {
                switch (menuItem.getItemId())
                {
                    case R.id.dashboard :
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.manage_drivers :
                        Intent intent =new Intent(HomeActivity.this,Manage_Drivers.class);
                        intent.putExtra("Drivers",i);
                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.manage_coupon :
                        Intent intent1 =new Intent(HomeActivity.this,Manage_Coupons.class);
                        startActivity(intent1);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.manage_admin :
                        Intent intent2 =new Intent(HomeActivity.this,Manage_Admin.class);
                        startActivity(intent2);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.manage_rides:
                        Intent intent3 =new Intent(HomeActivity.this,Manage_Rides.class);
                        startActivity(intent3);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.manage_riders :
                        Intent intent4 =new Intent(HomeActivity.this,Manage_riders.class);
                        startActivity(intent4);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.view_profile:
                        Intent intent5 =new Intent(HomeActivity.this,View_Profile.class);
                        startActivity(intent5);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.sign_out :
                        confirm confirm1=new confirm(getApplicationContext());
                        drawerLayout.closeDrawer(GravityCompat.START);
                        confirm1.sign_out();
                        break;
                    case R.id.change_password :
                        confirm confirm2=new confirm(HomeActivity.this);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        confirm2.forgot_password();
                        break;
                }

                return true;
            }
        });

        Calendar calendar=Calendar.getInstance(TimeZone.getDefault());
        int month,year,date,
        Date=calendar.get(Calendar.DATE);
        month=calendar.get(Calendar.MONTH)+1;
        year=calendar.get(Calendar.YEAR);
        textView1=findViewById(R.id.tv1);
        textView2=findViewById(R.id.tv2);
        textView3=findViewById(R.id.tv3);
        textView4=findViewById(R.id.tv11);
        textView5=findViewById(R.id.tv21);
        textView6=findViewById(R.id.tv31);
        init();
        //Toast.makeText(this,String.valueOf(Date)+""+String.valueOf(month)+""+String.valueOf(year),Toast.LENGTH_LONG).show();
    }

    private void init() {
        dbref=FirebaseDatabase.getInstance().getReference().child("E-Sathi_Driver");
        alist1=new ArrayList();
        dbref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                    i=i+1;
                    textView1.setText(String.valueOf(i));
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        dbref=FirebaseDatabase.getInstance().getReference().child("E-Sathi_User");
        alist2=new ArrayList();
        dbref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                    j=j+1;
                    textView2.setText(String.valueOf(String.valueOf(j)));
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void back(View view) {
        drawerLayout.closeDrawer(GravityCompat.START);

    }
}