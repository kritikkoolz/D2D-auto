package com.e_sathi.admin;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class Data_fetch extends Service {
    public Data_fetch() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}