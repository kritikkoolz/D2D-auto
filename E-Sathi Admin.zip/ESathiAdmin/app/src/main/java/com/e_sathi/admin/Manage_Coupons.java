package com.e_sathi.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Manage_Coupons extends AppCompatActivity {
    NavigationView nav;
    FirebaseUser user;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage__coupons);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        user= FirebaseAuth.getInstance().getCurrentUser();
        nav=(NavigationView)findViewById(R.id.navmenu);
        View headerView = nav.getHeaderView(0);
        TextView navUsername = (TextView)headerView.findViewById(R.id.email_nav);
        navUsername.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail().toString());
        drawerLayout=(DrawerLayout)findViewById(R.id.drawer);
        toggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
            {
                switch (menuItem.getItemId())
                {
                    case R.id.dashboard :
                        Intent intent1 =new Intent(Manage_Coupons.this,HomeActivity.class);
                        startActivity(intent1);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.manage_drivers :
                        Intent intent =new Intent(Manage_Coupons.this,Manage_Drivers.class);
                        startActivity(intent);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.manage_coupon :
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.manage_admin :
                        Intent intent2 =new Intent(Manage_Coupons.this,Manage_Admin.class);
                        startActivity(intent2);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.manage_rides:
                        Intent intent3 =new Intent(Manage_Coupons.this,Manage_Rides.class);
                        startActivity(intent3);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.manage_riders :
                        Intent intent4 =new Intent(Manage_Coupons.this,Manage_riders.class);
                        startActivity(intent4);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.view_profile:
                        Intent intent5 =new Intent(Manage_Coupons.this,View_Profile.class);
                        startActivity(intent5);
                        finish();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.sign_out :
                        confirm confirm1=new confirm(Manage_Coupons.this);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        confirm1.sign_out();
                        break;
                    case R.id.change_password :
                        confirm confirm2=new confirm(Manage_Coupons.this);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        confirm2.forgot_password();
                        break;
                }

                return true;
            }
        });

    }
}